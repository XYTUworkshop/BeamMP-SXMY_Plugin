-- SXMYVehicleTag Client ModScript / 客户端 modScript
-- Loads the GE extension when the mod is activated / mod 激活时加载 GE 扩展
setExtensionUnloadMode("SXMYVehicleTag", "manual")
extensions.load("SXMYVehicleTag")
