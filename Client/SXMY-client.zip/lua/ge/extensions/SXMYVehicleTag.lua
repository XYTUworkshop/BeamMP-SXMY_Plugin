-- ============================================================
-- SXMYVehicleTag - SXMY 专属车辆标签（客户端扩展）
-- Draws the player's nickname above every vehicle (including the
-- local player's own cars) and hides the BeamMP official tags
-- 在所有车辆上方（含玩家自己的车）绘制昵称，并隐藏 BeamMP 官方标签
-- Receives SXMY_NickUpdate events from the server
-- 接收服务器 SXMY_NickUpdate 事件
-- Requires the SXMY_Plugin server side for the events
-- 需要服务器端 SXMY_Plugin 下发事件
-- ============================================================

local M = {}

local ffi = require('ffi') -- LuaJIT FFI / FFI 接口
-- BeamNG native debug draw function, same one used by the official tags / BeamNG 原生调试绘制函数（官方标签同款）
local drawText = ffi and ffi.C and ffi.C.BNG_DBG_DRAW_TextAdvanced or nil
local tagPos = vec3() -- reusable world position / 可复用的世界坐标

local nickMap = {} -- ownerID -> nickname / 车主 ID -> 昵称
local hidden = false -- official tags hidden / 官方标签已隐藏

-- Hide the official tags once / 隐藏官方标签（一次）
local function hideOfficial()
    if not hidden and MPVehicleGE then
        MPVehicleGE.hideNicknames(true)
        hidden = true
    end
end

-- 接收服务器昵称更新事件 / handle nickname updates from the server
if MPGameNetwork then
    AddEventHandler("SXMY_NickUpdate", function(data)
        local d = jsonDecode(data)
        if not d then
            return
        end
        if d.remove then
            nickMap[d.pid] = nil
        elseif d.nick then
            nickMap[d.pid] = d.nick
        end
    end)
end

-- 每帧绘制昵称标签（含自己的车）/ draw nickname tags every frame (including own cars)
M.onPreRender = function()
    if not drawText or not MPVehicleGE then
        return
    end
    hideOfficial()
    local vehicles = MPVehicleGE.getVehicles()
    if not vehicles then
        return
    end
    for _, v in pairs(vehicles) do
        local vid = v.gameVehicleID
        local nick = nickMap[v.ownerID]
        if vid and nick and v.isSpawned then
            -- Cache the vehicle height / 缓存车辆高度
            if not v.vehicleHeight or v.vehicleHeight == 0 then
                local veh = getObjectByID(vid)
                if veh and veh.getInitialHeight then
                    v.vehicleHeight = veh:getInitialHeight()
                end
            end
            -- 车辆包围盒中心 / vehicle OOB center
            tagPos:set(be:getObjectOOBBCenterXYZ(vid))
            -- 官方同款高度：车顶上方 0.2 米 / same offset as the official tags: 0.2 m above the roof
            local heightOffset = (v.vehicleHeight or 2) * 0.5 + 0.2
            tagPos.z = tagPos.z + heightOffset
            -- 标签文字：登录昵称 | beamng账号 / label: login nickname | BeamNG account name
            local label = nick .. " | " .. (v.ownerName or "")
            drawText(tagPos.x, tagPos.y, tagPos.z, String(label), color(255, 255, 255, 255), true, false, color(0, 0, 0, 150), false, false)
        end
    end
end

return M
